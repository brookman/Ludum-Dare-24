/**
 * 
 */

package math.geom3d.curve;

/**
 * @author dlegland
 */
public interface ContinuousCurve3D extends Curve3D {

}
